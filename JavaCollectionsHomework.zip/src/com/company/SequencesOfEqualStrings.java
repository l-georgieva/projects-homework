package com.company;

import java.util.*;

public class SequencesOfEqualStrings {

    public static void main(String[] args) {
        // write your code here
        Scanner input = new Scanner(System.in);
        String str = input.nextLine();

        String[] arrStr = str.split(" ");

        System.out.print(arrStr[0]);
        for (int i = 1; i < arrStr.length; i++) {
            if (arrStr[i].equals(arrStr[i - 1])) {
                System.out.print(" " + arrStr[i]);
            } else {
                System.out.println();
                System.out.print(arrStr[i]);
            }
        }

    }

}




