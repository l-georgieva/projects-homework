package com.company;


import java.util.Arrays;
import java.util.Scanner;

/**
 * Created by Admin on 3/30/2016.
 */
public class ExtractAllUniqueWords {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String str = input.nextLine().toLowerCase();
        String[] arrStr = str.split("\\W+");

        Arrays.sort(arrStr);

        System.out.print(arrStr[0] + " ");
        for (int i = 1; i < arrStr.length; i++) {
            if (arrStr[i].equals(arrStr[i - 1])) {
                continue;
            }
            System.out.print(arrStr[i] + " ");
        }

    }
}

