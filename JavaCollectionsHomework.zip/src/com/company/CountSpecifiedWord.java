package com.company;

import java.util.Scanner;

/**
 * Created by Admin on 3/30/2016.
 */
public class CountSpecifiedWord {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String str = input.nextLine();
        String word = input.nextLine();

        String[] arrStr = str.split("\\W+");

        int count = 0;
        for (int i = 0; i < arrStr.length; i++) {
            if (arrStr[i].toLowerCase().equals(word)) {
                count++;
            }
        }
        System.out.println(count);

    }

}

