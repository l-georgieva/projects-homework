package com.company;

import java.util.Scanner;

/**
 * Created by Admin on 3/30/2016.
 */
public class CountAllWords {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String str = input.nextLine();

        String[] arrStr = str.split("\\W+");

        System.out.println(arrStr.length);
    }
}

