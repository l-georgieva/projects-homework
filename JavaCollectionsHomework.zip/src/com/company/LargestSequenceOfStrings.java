package com.company;

import java.util.Scanner;

public class LargestSequenceOfStrings {

    public static void main(String[] args) {
        //
        Scanner input = new Scanner(System.in);
        String str = input.nextLine();

        String[] arrStr = str.split(" ");

        int largestSeq = 1;
        int index = 0;
        int largestTemp = 1;

        for (int i = 1; i < arrStr.length; i++) {
            if (arrStr[i].equals(arrStr[i - 1])) {
                largestTemp++;
            } else {
                largestTemp = 1;
            }

            if (largestTemp > largestSeq) {
                largestSeq = largestTemp;
                index = i - largestSeq + 1;
            }

        }
        for (int i = 0; i < largestSeq; i++) {

            System.out.print(arrStr[index] + " ");
        }

    }

}


