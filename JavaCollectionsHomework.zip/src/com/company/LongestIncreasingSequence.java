package com.company;

import java.util.Scanner;

public class LongestIncreasingSequence {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String str = input.nextLine();

        String[] arrStr = str.split(" ");
        int[] numbers = new int[arrStr.length];

        for (int i = 0; i < numbers.length; i++) {
            numbers[i] = Integer.parseInt(arrStr[i]);
        }

        int largestSeq = 1;
        int index = 0;
        int largestTemp = 1;

        System.out.print(numbers[0]);

        for (int i = 1; i < arrStr.length; i++) {
            if (numbers[i] > numbers[i - 1]) {
                largestTemp++;
                System.out.print(" " + numbers[i]);

            } else {
                largestTemp = 1;

                System.out.println();
                System.out.print(numbers[i]);
            }


            if (largestTemp <= largestSeq) {
                continue;
            }
            largestSeq = largestTemp;
            index = i;

        }

        System.out.println();

        System.out.print("Longest: ");

        for (int i = 0; i < largestSeq; i++) {

            System.out.print(arrStr[index - largestSeq + 1 + i] + " ");
        }

    }

}
